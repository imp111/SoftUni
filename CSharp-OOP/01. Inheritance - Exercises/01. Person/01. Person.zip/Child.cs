﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01._Inheritance___Exercises
{
    internal class Child : Person
    {
        public Child(string name, int age) : base(name, age)
        {

        }
    }
}
